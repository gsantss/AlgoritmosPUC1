#include <stdio.h>
    /* Utilizando a estrutura de repetição FOR, implemente um programa que calcule e escreva a seguinte soma:

soma = (1/1 + 3/2 + 5/3 + 7/4 + ... + 99/50) */
int main(void) {
  float n = 1;
  float d = 1;
  float sum = 0;
  for(n=1;n<=99;n+=2){
    sum+=(n/d);
    d++;
  }
  printf("Valor final da soma: %.2f", sum);
  return 0;
}