#include <stdio.h>
  /* Utilizando a estrutura de repetição FOR, implemente um programa para ler as notas de 10 alunos e após calcule e mostre a média da turma, a maior e a menor nota verificada. */
int main(void) {
  float note = 0;
  float total = 0;
  float avg = 0;
  float i = 0;
  
  for(i=0;i<10;i++){
    printf("Informe a nota do aluno: \n");
    scanf("%f", &note);
    total+=note;
    
  }
  avg = total/10;
  printf("A média das notas foi de: %.2f", avg);
  return 0;
}