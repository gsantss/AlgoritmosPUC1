#include <stdio.h>

  /* Faça um programa que leia uma série de números inteiros  positivos e que, a cada número lido, mostre o seu  fatorial.

Onde:  n ! = n x (n-1) x (n-2) x ...... x 2 x 1

Lembrando:   1 ! = 1               0 ! = 1 */
int main(void) {
  int check = 1;
  int num = 0;
  int aNum = 0;
  int nNum = 0;
  int rNum = 0;
  int result = 1;

  while(check != 0){
    printf("\n\nInforme um número para determinar seu fatorial ou 0 para finalizar \n\n");
    scanf("%i", &num);
    aNum = num;
    if(num != 0 && num != 1){
      while(num>1){
        nNum = num-1;
        rNum = aNum*nNum;
        printf("\n%i * %i = %i", aNum, nNum, rNum);
        num--;
        aNum = rNum;
        nNum--;
      }
      printf("\nResultado final: %i", rNum);
      rNum = 0;
    } else if(num == 1){
        printf("Fatorial de 1 = 1");
      } else {
        check = 0;
        printf("\nFatorial de 0 = 1");
        printf("\nFim do Programa!");
    }
  }
  return 0;
}