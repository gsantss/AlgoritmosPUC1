#include <stdio.h>

/*Utilizando a estrutura de repetição FOR, faça um programa que leia um número inteiro qualquer e após a leitura, mostre os 20 primeiros múltiplos deste número.

Exemplo:   

N=2

Múltiplo 1 = 2        Múltiplo 2 = 4     ................................     Múltiplo 20 = 40*/
int main(void) {
  int num = 0;
  int mult = 0;
  int m = 1;

  printf("\nInforme um numero: ");
  scanf("%i", &num);
  for(m=1;m<=20;m++){
    mult = num * m;
    printf("\n\nMultiplo: %i \nResultado: %i", m, mult);
  }
  return 0;
}