#include <stdio.h>
/* Utilizando a estrutura de repetição FOR,  faça um programa que leia uma série de 10 números e ao término informe a quantidade de números pares e a quantidade de números impares desta série. */

int main(void) {
  int num =0;
  int i = 0;
  int cp = 0;
  int ci = 0;

  for(i=0;i<10;i++){
    printf("\nInforme um número: ");
    scanf("%i", &num);
    if(num%2 == 0){
      cp++;
    } else {
      ci++;
    }
  }
  printf("\n\nQuantidade de pares: %i \nQuantidade de impares: %i", cp, ci);
  return 0;
}