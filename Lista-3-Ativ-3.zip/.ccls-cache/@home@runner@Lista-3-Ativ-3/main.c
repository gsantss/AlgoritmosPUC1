#include <stdio.h>
/* A conversão de graus Farenheit para Centígrados é obtida por  

C = 5/9 ( F - 32 ) .

Utilizando a estrutura de repetição FOR, implemente um programa que calcule e escreva uma tabela de graus Centígrados em função de graus Farenheit, que variam de 50 a 100, de 5 em 5. */
int main(void) {
  float f = 0;
  float c = 0;
  float cont = 50;

  for(f=50; f<=100; f+=5){
    c = (f-32)* 5/9;
    printf("\nFarenheit: %.2f \nCentígrados: %.2f", f, c);
  }
  return 0;
}