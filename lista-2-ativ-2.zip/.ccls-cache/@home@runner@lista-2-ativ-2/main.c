#include <stdio.h>
 /* Faça um programa para ler o consumo de energia elétrica em um bairro com consumidores divididos de acordo com os tipos (Residência=1/Comércio=2) e ao término mostre:

a) a quantidade de consumidores de cada tipo;

b) a média de consumo das residências;

c) a média de consumo do comércio;

d) a média de consumo do bairro.*/
int main(void) {
  float check = 0;
  float type = 0;
  float qttR = 0;
  float qttC = 0;
  float consR = 0;
  float tConsR = 0;
  float consC = 0;
  float tConsC = 0;

  while (check != 3){
    printf("\n\nInforme o tipo de consumidor: \n1 - Residência \n2 - Comércio \n3 - Finalizar\n");
    scanf("%f", &type);
    if(type == 1){
      qttR++;
      printf("\n\nInforme em kilowatts o consumo:\n");
      scanf("%f", &consR);
      tConsR+=consR;
    } else if(type == 2){
      qttC++;
      printf("\n\nInforme em kilowatts o consumo:\n");
      scanf("%f", &consC);
      tConsC+=consC;
    } else{
      check = 3;
    }
  }
  printf("\n\na) a quantidade de consumidores de cada tipo, Residência e Comércio, respectivamente: %.0f e %.0f", qttR, qttC);
  printf("\n\nb) a média de consumo das residências: %.0f / %.0f = %.0f", tConsR, qttR, (tConsR/qttR));
  printf("c) a média de consumo do comércio: %.0f / %.0f = %.0f", tConsC, qttC, (tConsC/qttC));
  printf("\n\nd) a média de consumo do bairro: (%.0f + %.0f) / (%.0f + %.0f) = %.0f", tConsR, tConsC, qttR, qttC, ((tConsR + tConsC) / (qttR + qttC)));
  return 0;
}