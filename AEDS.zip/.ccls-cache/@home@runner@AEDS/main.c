#include <stdio.h>

int main(void) {

  /*Faça um programa para ler a idade, o gênero (masc=1/fem=2) e o peso de 5
pessoas.

Após as leituras dos dados mostre:

O número de homens e o número de mulheres;
A média dos pesos dos homens;
A média das idades das mulheres;
A média do peso e das idades do grupo;*/

  float iw = 0;
  float ia = 0;
  float ga = 0;
  float pa = 0;
  float pm = 0;
  float nm = 0;
  float nf = 0;
  float mf = 0;
  float mm = 0;
  float mp = 0;
  float mi = 0;
  float pt = 0;
  float it = 0;
  float cont = 0;

  while (cont < 5) {
    printf("\n\nInforme a sua idade: \n");
    scanf("%f", &ia);
    printf("Informe o seu gênero: 1 - Masc 2 - Fem \n");
    scanf("%f", &ga);
    printf("Informe o seu peso: \n");
    scanf("%f", &pa);
    if (ga == 1) {
      nm++;
      pm += pa;
      it += ia;
      pt += pa;
    } else {
      nf++;
      iw += ia;
      it += ia;
      pt += pa;
    }
    cont++;
  }
  mm = pm / nm;
  mf = iw / nf;
  mp = pt / cont;
  mi = it / cont;

  printf("\n\nO numero de homens e mulheres foram respectivamente: %.0f e %.0f",
         nm, nf);
  printf(
      "\n\nA media geral de peso e idades foram respectivamente: %.0f e %.0f",
      mp, mi);
  printf("\n\nA media do peso dos homens foi de: %.0f", mm);
  printf("\n\nA idade media das mulheres é de: %.0f", mf);
  return 0;
}