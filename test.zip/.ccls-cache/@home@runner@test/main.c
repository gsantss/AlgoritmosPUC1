#include <stdio.h>
#include <math.h>

int main(void) {
  int x = 0;
  int s = 0;
  int ss = 0;
  for(x=0;x<=12;x++){
    s = s + pow(x,2);
    printf("%i \n", s);
    
 }
  printf("\n");
  for(x=0;x<=12;x++){
    ss += x;
    printf(" %i \n", ss);
  }
  ss = pow(ss,2);
  printf("\n %i \n %i", s, ss);
  return 0;
}