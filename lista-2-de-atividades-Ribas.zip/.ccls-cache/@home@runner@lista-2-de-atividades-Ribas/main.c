#include <stdio.h>

int main(void) {
  /* Faça um programa para ler uma sucessão de lançamentos de uma moeda onde (Cara=1 / Coroa=2).

Ao término, mostre a ocorrência de cada face e a face que teve a maior ocorrência */

  int check = 0;
  int resultf = 0;
  int resultb = 0;
  int choice = 0;

  while(check != 3){
    printf("\n\nInforme: \n1 - Cara \n2 -Coroa \n3 - Encerrar e mostrar resultados \n");
    scanf("%i", &choice);
    if(choice == 1){
      resultf++;
    } else if(choice == 2){
      resultb++;
    } else{
      check = 3;
    }
  }
  if(resultf > resultb){
    printf("\n\nA ocorrência de cara foi maior: %i", resultf);
    printf("\nCaras: %i \nCoroas: %i", resultf, resultb);
  } else if(resultb > resultf){
    printf("\n\nA ocorrência de coroa foi maior: %i", resultb);
    printf("\nCaras: %i \nCoroas: %i", resultf, resultb);
  } else {
    printf("\n\nA ocorrência de ambos foram iguais");
    printf("\nCaras: %i \nCoroas: %i", resultf, resultb);
  }
  
  return 0;
}