#include <stdio.h>

int main(void) {
  /* Faça um programa para ler a idade de um grupo de pessoas e ao término mostre:

a) o número de mulheres e o número de homens;

b) a média das idades dos homens.

c) a maior idade verificada;

d) a menor idade verificada; */
  
  float check = 0;
  float sex = 0;
  float age = 0;
  float tAgeM = 0;
  float tAgeF = 0;
  float numM = 0;
  float numF = 0;
  float maxAge = -99999;
  float minAge = 99999;

  while(check != 3){
    printf("\n\nInforme seu gênero ou 3 para finalizar: \n1 - Masc \n2 - Fem\n\n");
    scanf("%f", &sex);
    if(sex != 3){
      if(sex == 1){
        printf("\n\nInforme a sua idade: \n");
        scanf("%f", &age);
        tAgeM += age;
        numM++;
        if(age>maxAge){
          maxAge = age;
        } else if(age<minAge){
          minAge = age;
        }
      } else if(sex == 2){
        printf("\n\nInforme a sua idade: \n");
        scanf("%f", &age);
        tAgeF += age;
        numF++;
        if(age>maxAge){
          maxAge = age;
        } else if(age<minAge){
          minAge = age;
        }
      }
    } else {
      check = 3;
    }
  }
  printf("\n\na) o número de mulheres e o número de homens, respectivamente: %.0f e %.0f", numF, numM);

printf("\nb) a média das idades dos homens: %.0f / %.0f = %.0f", tAgeM, numM, (tAgeM / numM));

printf("\nc) a maior idade verificada: %.0f", maxAge);

printf("\nd) a menor idade verificada: %.0f", minAge);
  return 0;
}