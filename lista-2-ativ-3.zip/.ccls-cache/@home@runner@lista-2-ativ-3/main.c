#include <stdio.h>

int main(void) {
 /* Faça um programa para ler o consumo de água em (m3) das residências de um bairro e ao término mostre:

a) a média do consumo de água verificado neste bairro;

b) o número de consumidores analisados;

c) o maior e o menor consumos verificados; */

  float check = 1;
  float cons = 0;
  float tCons = 0;
  float numP = 0;
  float maxCons = -99999;
  float minCons = 99999;

  while (check != 0){
    printf("\n\n Informe o consumo de água em L/m³ ou 0 para finalizar: \n");
    scanf("%f", &cons);
    if(cons!=0){
      if(cons>maxCons){
        maxCons = cons;
        tCons+=cons;
        numP++;
      } else if(cons<minCons){
        minCons= cons;
        tCons+=cons;
        numP++;
      } else if(cons == maxCons || cons == minCons){
        numP++;
        tCons+=cons;
      }
    } else {
      check = 0;
    }
  }
  printf("\n\na) a média do consumo de água verificado neste bairro: %.0f / %.0f = %.0f", tCons, numP, (tCons/numP));

printf("\n\nb) o número de consumidores analisados: %.0f", numP);

printf("\n\nc) o maior e o menor consumos verificados, respectivamente: %.0f e %.0f", maxCons, minCons);
  return 0;
}