#include <stdio.h>

int main(void) {
  /* Faça um programa para ler uma série de números e ao término mostre:

a) a média verificada;

b) o maior número lido;

c) o menor número lido. */

  float num = 0;
  float tnum = 0;
  float qttNum = 0;
  float check = 1;
  float maxNum = -99999;
  float minNum = 99999;
  float avgNum = 0;

  while(check != 0){
    printf("\n\nInforme um número para determinar a média conforme a sequência ou 0 para finalizar a sequência: \n");
    scanf("%f", &num);
    if(num!=0){
      tnum+=num;
      qttNum++;
      if(num>maxNum){
        maxNum = num;
      } else if(num<minNum){
        minNum = num;
      }
    } else {
      check = 0;
    }
  }
  printf("\n\na) a média verificada: %.0f / %.0f = %.2f", tnum, qttNum, (tnum / qttNum));

printf("\nb) o maior número lido: %.0f", maxNum);

printf("\nc) o menor número lido: %.0f", minNum);
  return 0;
}